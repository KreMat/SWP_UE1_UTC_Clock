/**
 * 
 */
package at.technikum.wien.winterhalder.kreuzriegler.swp.clock.view;

/**
 * @author richie
 *
 */
public interface ClockObserver {

	public void update();
}
