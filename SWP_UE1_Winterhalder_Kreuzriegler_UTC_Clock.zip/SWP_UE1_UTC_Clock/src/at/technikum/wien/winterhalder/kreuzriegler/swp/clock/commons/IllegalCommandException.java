/**
 * 
 */
package at.technikum.wien.winterhalder.kreuzriegler.swp.clock.commons;

/**
 * @author Matthias
 * 
 */
public class IllegalCommandException extends Exception {

	private static final long serialVersionUID = -5058364826115513L;

	public IllegalCommandException(String msg) {
		super(msg);
	}

}
